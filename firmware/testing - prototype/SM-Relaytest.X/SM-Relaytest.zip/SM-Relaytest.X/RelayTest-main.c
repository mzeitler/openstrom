/* 
 * File:   RelayTest-main.c
 * Author: Anton Tachev
 *
 * Created on:10.12.2015, 10:57
 */

#include <stdio.h>
#include <stdlib.h>
#include <plib.h>
#include <p32xxxx.h>

// Configuration Bit settings
// SYSCLK = 80 MHz (8MHz Crystal/ FPLLIDIV * FPLLMUL / FPLLODIV)
// PBCLK = 40 MHz
// Primary Osc w/PLL (XT+,HS+,EC+PLL)
// WDT OFF
// Other options are don't care

#pragma config FPLLMUL = MUL_20, FPLLIDIV = DIV_2, FPLLODIV = DIV_1, FWDTEN = OFF
#pragma config POSCMOD = HS, FNOSC = PRIPLL, FPBDIV = DIV_1
/*------------------------------------------------------------------*/
 /*                    Relay's connections description              */
 /*                                                                 */
 /*   Relay_01 - RF1                  */
 /*   Relay_02 - RF0                  */
 /*   Relay_03 - RD7                  */
 /*   Relay_04 - RD6                  */
 /*   Relay_05 - RD5                  */
 /*   Relay_06 - RD4                  */
 /*   Relay_07 - RC14                 */
 /*   Relay_08 - RC13                 */
 /*   Relay_09 - RB8                  */
 /*   Relay_10 - RB10                 */
 /*------------------------------------------------------------------*/
int bits[16]={BIT_0,BIT_1,BIT_2,BIT_3,BIT_4,BIT_5,BIT_6,BIT_7,
              BIT_8,BIT_9,BIT_10,BIT_11,BIT_12,BIT_13,BIT_14,BIT_15};
int main(void)
{
    unsigned int delayValue,i,j;
    //static const float rxBuff[]={1234,6,2345.11};
    //Set pins Direction
    
    mPORTFSetPinsDigitalOut(BIT_0|BIT_1);               //set directions of PORT pins
    mPORTDSetPinsDigitalOut(BIT_7|BIT_6|BIT_5|BIT_4);
    mPORTCSetPinsDigitalOut(BIT_14|BIT_13);
    mPORTBSetPinsDigitalOut(BIT_8|BIT_10);
    
    mPORTFSetBits(BIT_0|BIT_1);                         //Set pins to non active state
    mPORTDSetBits(BIT_7|BIT_6|BIT_5|BIT_4);
    mPORTCSetBits(BIT_14|BIT_13);
    mPORTBSetBits(BIT_8|BIT_10);
    while(1){
        for(i=0;i<16;i++)
        {
          mPORTFToggleBits(bits[i]);
          delayValue=100*100;
          while(delayValue--);
         mPORTFClearBits(bits[i]);
        }   
   }
   
}

